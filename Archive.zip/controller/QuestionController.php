<?php

/**
 * Created by PhpStorm.
 * User: adripol94
 * Date: 1/28/17
 * Time: 5:45 PM
 */

require_once "Controller.php";

class QuestionController extends Controller
{
    public function manageGetVerb(Request $r)
    {
        $listQuestion = null;
        $code = null;
        $id = null;
        $response = null;

        if (isset($r->getUrlElements()[2]))
            $id = $r->getUrlElements()[2];

        $listQuestion = QuestionHandlerModel::getQuestion($id);

        if ($listQuestion != null) {
            $code = '200';
        } else {
            if (Validate::isValid($id)) {
                $code = '404';
            } else {
                $code = '400';
            }
        }


        $response = new Response($code, null, $listQuestion, $r->getAccept());
        return $response;
    }

}