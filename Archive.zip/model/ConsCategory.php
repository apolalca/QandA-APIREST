<?php

/**
 * Created by PhpStorm.
 * User: apol
 * Date: 24/11/16
 * Time: 10:15
 */

namespace ConsDB;

class ConsCategory
{
    // Consts for categry table
    const TABLE_CATEGORYS = "Categories";
    const ID = "id";
    const CATEGORY_NAME = "Category_Name";

}