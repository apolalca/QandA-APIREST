<?php

/**
 * Created by PhpStorm.
 * User: adripol94
 * Date: 1/27/17
 * Time: 6:48 PM
 */

namespace ConsDB;


class ConsAnswer
{
    const TABLE_NAME = "Answers";
    const ANSWER = "answer";
    const ID = "id";
    const CORRECT = "correct";
}