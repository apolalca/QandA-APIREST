<?php
/**
 * Created by PhpStorm.
 * User: adripol94
 * Date: 1/31/17
 * Time: 5:49 PM
 */

namespace ConsDB;


class ConsRoll
{
    const NAME_TABLE = "Rolls";
    const ID = "id";
    const NAME_Roll = "Name";
    const DESCRIPTION_ROLL = "Description_Roll";
}