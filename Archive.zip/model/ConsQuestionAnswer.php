<?php
/**
 * Created by PhpStorm.
 * User: adripol94
 * Date: 1/27/17
 * Time: 6:55 PM
 */

namespace ConsDB;


class ConsQuestionAnswer
{
    const TABLE_NAME = "QuestionsAnswers";
    const IDQUESTION = "idQuestion";
    const IDANSWER = "idAnswer";
}