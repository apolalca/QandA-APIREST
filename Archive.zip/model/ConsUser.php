<?php

/**
 * Created by PhpStorm.
 * User: apol
 * Date: 19/01/17
 * Time: 11:09
 */

namespace ConsDB;

class ConsUser
{

    const NAME_TABLE = "Users";
    const ID = "id";
    const USER = "user";
    const PASSWORD = "password";
    const AGE = "age";
    const SURNAME = "surname";
    const NAME = "name";
    const EMAIL = "email";
}