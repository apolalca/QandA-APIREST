<?php

/**
 * Created by PhpStorm.
 * User: adripol94
 * Date: 1/27/17
 * Time: 5:58 PM
 */

namespace ConsDB;

class ConsQuestion
{
    const TABLE_NAME = "Questions";
    const ID = "id";
    const DIFFICULTY = "Difficulty";
    const IDCATEGORIES = "idCategory";
}